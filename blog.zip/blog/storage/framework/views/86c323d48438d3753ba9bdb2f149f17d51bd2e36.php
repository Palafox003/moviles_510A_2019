<?php $__env->startSection('titulo','Usuarios'); ?>

<?php $__env->startSection('contenido'); ?>

	<h2>LISTA DE USUARIOS</h2>

	<table class="table">
		<tr>
			<th>#</th>
			<th>NOMBRE</th>
			<th>MATRICULA</th>
			<th>EMAIL</th>
			<th>ROLL</th>
			<th>DIRECCIÓN</th>
			<th>EDITAR</th>
			<th>ELIMINAR</th>
		</tr>
<?php $__currentLoopData = $usuarios; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $usuario): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
		<tr>
			<td><?php echo e(($loop->index+1)); ?></td>
			<td><?php echo e($usuario->nombre); ?> <?php echo e($usuario->paterno); ?> <?php echo e($usuario->materno); ?></td>
			<td><?php echo e($usuario->matricula); ?></td>
			<td><?php echo e($usuario->email); ?></td>
			<td><?php echo e($usuario->roll); ?></td>
			<td><a class="btn btn-primary" href="/nuevaDireccion/<?php echo e($usuario->id); ?>" role="button">Agregar</a></td>
			<td><a class="btn btn-primary" href="#" role="button">Editar</a></td>
			<td>
				<form method="post" action="#">
					<input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
					<input type="hidden" name="_method" value="DELETE">
					<input class="btn btn-danger" type="submit" name="Value" value="Eliminar">
				</form>
			</td>
		</tr>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	</table>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>