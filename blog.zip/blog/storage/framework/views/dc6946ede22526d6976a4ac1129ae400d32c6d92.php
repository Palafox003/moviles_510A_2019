<?php $__env->startSection('titulo','Nueva Dirección'); ?>

<?php $__env->startSection('contenido'); ?>
  <h2>NUEVA DIRECCIÓN</h2>
  <h3>USUARIO:<?php echo e($user->nombre); ?> <?php echo e($user->paterno); ?> <?php echo e($user->materno); ?></h3>

<?php if($errors->any()): ?>
    <div class="alert alert-danger">
        <ul>
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li><?php echo e($error); ?></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    </div>
<?php endif; ?>

<form method="post" action="/direcciones">
	<input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
  <div class="form-group">
    <label for="estado">Estado:</label>
    <input type="text" class="form-control" name="estado" id="estado" aria-describedby="estado" placeholder="estado del usuario">
  </div>
  <div class="form-group">
    <label for="ciudad">Ciudad:</label>
    <input type="text" class="form-control" name="ciudad" id="paterno">
  </div>
  <div class="form-group">
    <label for="colonia">Colonia:</label>
    <input type="text" class="form-control" name="colonia" id="colonia" placeholder="Editorial del libro">
  </div>
  <div class="form-group">
    <label for="cp">C.P:</label>
    <input type="text" class="form-control" name="cp" id="cp" >
  </div>
  <div class="form-group">
    <label for="calle">Calle:</label>
    <input type="text" class="form-control" name="calle" id="calle">
  </div>
  <div class="form-group">
    <label for="numero">Número:</label>
    <input type="text" class="form-control" name="numero" id="numero">
  </div>
  <input type="hidden" name="user_id" value="<?php echo e($user->id); ?>">
  
  <button type="submit" class="btn btn-primary">Guardar</button>
</form>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>