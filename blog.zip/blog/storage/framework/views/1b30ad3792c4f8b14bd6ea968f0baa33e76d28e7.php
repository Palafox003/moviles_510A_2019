<?php $__env->startSection('titulo','Libros'); ?>

<?php $__env->startSection('contenido'); ?>

	<h2>LISTA DE LIBROS</h2>

	<table class="table">
		<tr>
			<th>#</th>
			<th>ID</th>
			<th>NOMBRE</th>
			<th>AUTOR</th>
			<th>EDITORIAL</th>
			<th>ISBN</th>
			<th>EDICIÓN</th>
			<th>CARRERA</th>
			<th>EDITAR</th>
			<th>ELIMINAR</th>
		</tr>
<?php $__currentLoopData = $libros; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $libro): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
		<tr>
			<td><?php echo e(($loop->index+1)); ?></td>
			<td><?php echo e($libro->id); ?></td>
			<td><?php echo e($libro->nombre); ?></td>
			<td><?php echo e($libro->autor); ?></td>
			<td><?php echo e($libro->editorial); ?></td>
			<td><?php echo e($libro->isbn); ?></td>
			<td><?php echo e($libro->edicion); ?></td>
			<td><?php echo e($libro->carrera()->first()->nombre); ?></td>
			<td><a class="btn btn-primary" href="#" role="button">Editar</a></td>
			<td>
				<form method="post" action="#">
					<input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
					<input type="hidden" name="_method" value="DELETE">
					<input class="btn btn-danger" type="submit" name="Value" value="Eliminar">
				</form>
			</td>
		</tr>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	</table>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>