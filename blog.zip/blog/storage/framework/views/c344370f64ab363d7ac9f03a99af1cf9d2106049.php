<?php $__env->startSection('titulo','Carreras'); ?>

<?php $__env->startSection('contenido'); ?>

	<h2>LISTA DE CARRERAS</h2>

	<table class="table">
		<tr>
			<th>#</th>
			<th>ID</th>
			<th>CARRERA</th>
			<th>LOGO</th>
			<th>EDITAR</th>
			<th>ELIMINAR</th>
		</tr>
<?php $__currentLoopData = $carreras; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $carrera): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
		<tr>
			<td><?php echo e(($loop->index+1)); ?></td>
			<td><?php echo e($carrera->numero); ?></td>
			<td><?php echo e($carrera->nombre); ?></td>
			<td><?php echo e($carrera->logo); ?></td>
			<td><a class="btn btn-primary" href="/carreras/<?php echo e($carrera->id); ?>/edit" role="button">Editar</a></td>
			<td>
				<form method="post" action="/carreras/<?php echo e($carrera->id); ?>">
					<input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
					<input type="hidden" name="_method" value="DELETE">
					<input class="btn btn-danger" type="submit" name="Value" value="Eliminar">
				</form>
			</td>
		</tr>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	</table>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>