export class Post {
    id: number;
    numero: number;
    nombre:string;
    logo:string;
    created_at:string;
    updated_at:string;
  }